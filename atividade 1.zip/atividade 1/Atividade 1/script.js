let btCalcular = document.querySelector("#btCalcular");
let inputNum1 = document.querySelector("#inputNum1");
let inputNum2 = document.querySelector("#inputNum2");
let resultado = document.querySelector("#resultado");

function somarNumeros(){

    //puxar valores dos campos, e transformar em numeros 
    let num1 = Number(inputNum1.value);
    let num2 = Number(inputNum2.value);

    resultado.textContent = (num1 + num2);
}

btCalcular.onclick = function(){
    somarNumeros();
}
