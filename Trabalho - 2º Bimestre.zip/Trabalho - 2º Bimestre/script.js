//1-Encontre o triangulo
let inputTriangulo1TRI = document.querySelector("#inputTriangulo1TRI");
let inputTriangulo2TRI = document.querySelector("#inputTriangulo2TRI");
let inputTriangulo3TRI = document.querySelector("#inputTriangulo3TRI");
let btInformarTRI = document.querySelector("#btInformarTRI");
let h4ResultadoTRI = document.querySelector("#h4ResultadoTRI");

function Encontreotriangulo(){

    let num1 = Number(inputTriangulo1TRI.value);
    let num2 = Number(inputTriangulo2TRI.value);
    let num3 = Number(inputTriangulo3TRI.value);

    if (num1 === 0 || num2 === 0 || num3 ===0) {

        h4ResultadoTRI.textContent = "NAO E UM TRIANGULO"

    
    } else {
        
        if(num1 === num2 && num1 === num3 && num2 === num3){
            h4ResultadoTRI.textContent = "Triangulo Equilatero"
        }else
        if(num1 === num2 || num1 === num3 || num2 === num3){
            h4ResultadoTRI.textContent = "Triangulo Isosceles"
        }else {
            h4ResultadoTRI.textContent = "Triangulo escaleno"
        }   
    }
  
}
btInformarTRI.onclick = function(){
    Encontreotriangulo();
}

// Calculadora IMC

let inputPesoIMC = document.querySelector("#inputPesoIMC");
let inputAlturaIMC = document.querySelector("#inputAlturaIMC");
let btCalcularIMC = document.querySelector("#btCalcularIMC");
let h4ResultadoCalcularIMC = document.querySelector("#h4ResultadoCalcularIMC");

function CalcularIMC (){
    let peso = Number(inputPesoIMC.value);
    let altura = Number(inputAlturaIMC.value);
    let IMC

    IMC = peso / (altura*altura)

    if( IMC < 18.5 ){
        h4ResultadoCalcularIMC.textContent = "Abaixo do peso  "+IMC.toFixed(0)+" IMC"
    }
    if( IMC > 18.5 && IMC < 24.9){
        h4ResultadoCalcularIMC.textContent = "peso Normal  "+IMC.toFixed(0)+" IMC"
    }
    if( IMC > 25 && IMC < 29.9){
        h4ResultadoCalcularIMC.textContent = "Sobre peso  "+IMC.toFixed(0)+" IMC"
    }
    if( IMC > 30 && IMC < 34.9){
        h4ResultadoCalcularIMC.textContent = "Obesidade grau 1  "+IMC.toFixed(0)+" IMC"
    }
    if( IMC > 35 && IMC < 39.9){
        h4ResultadoCalcularIMC.textContent = "Obesidade grau 2  "+IMC.toFixed(0)+" IMC"
    }
     
    if( IMC > 40){
        h4ResultadoCalcularIMC.textContent = "Obesidade grau 3  "+IMC.toFixed(0)+" IMC"
    }


}

btCalcularIMC.onclick = function(){
    CalcularIMC();
}

// Calcular Imposto

let inputAnoIMP = document.querySelector("#inputAnoIMP");
let inputValorTabelaIMP = document.querySelector("#inputValorTabelaIMP");
let btCalcularIMPOSTO = document.querySelector("#btCalcularIMPOSTO");
let h4ResultadoPagarIMP = document.querySelector("#h4ResultadoPagarIMP");

function CalcularImposto(){
    let Ano = Number(inputAnoIMP.value);
    let ValorCarro = Number(inputValorTabelaIMP.value);
    let num1
    let imposto
    

    if( Ano < 1990){
        num1 = ValorCarro * (1/100) 
        imposto = ValorCarro + num1
        
        h4ResultadoPagarIMP.textContent = "Total de R$"+imposto.toFixed(2)+" com 1% de imposto"
    } else if( Ano >= 1990){
        num1 = ValorCarro *(1.5/100)
        imposto = ValorCarro + num1

        h4ResultadoPagarIMP.textContent = "Total de R$"+imposto.toFixed(2)+" com 1.5% de imposto"
    }

}

btCalcularIMPOSTO.onclick = function(){
    CalcularImposto();
}

// Calcular Salario

let inputSALARIO = document.querySelector("#inputSALARIO");
let btCalcularSalario = document.querySelector("#btCalcularSalario");
let h4ResultadoSalario = document.querySelector("#h4ResultadoSalario");
let cargo = document.querySelector ("#SelectCargoSAL");

function CalcularSalario(){
    let salario = Number(inputSALARIO.value)
    let cargo = (SelectCargoSAL.value)
    let percentual
    let aumento
    let SalarioAumento

    switch (cargo){
        case "101SAL":
          percentual = 10;
          break;
        case "102SAL":
          percentual = 20;
          break;
        case "103SAL":
          percentual = 30;
          break;
        case "outrosSAL":
        default:
          percentual = 40;
    }

    aumento = salario * (percentual/100)
    SalarioAumento = salario + aumento

    h4ResultadoSalario.innerHTML = "Salario Atual R$"+salario.toFixed(2)+"<br>"+" Salario Novo R$"
    +SalarioAumento.toFixed(2)+"<br>"+" Aumento foi de R$"+aumento.toFixed(2);

}
btCalcularSalario.onclick = function(){
    CalcularSalario();
}

// Calcular Credito Bancario

let inputSaldoMedioCRE = document.querySelector("#inputSaldoMedioCRE");
let btCalcularCREDITO = document.querySelector("#btCalcularCREDITO");
let h4ResultadoCREDITO = document.querySelector("#h4ResultadoCREDITO");

function CalcularCreditoBancario(){
    let SaldoMedio = Number(inputSaldoMedioCRE.value);
    let aumentoCRE
    let SaldoFinal
    

    if( SaldoMedio >= 0 && SaldoMedio <= 200){
        h4ResultadoCREDITO.textContent = "Nao ha Credito"
    }
    if( SaldoMedio >= 201 && SaldoMedio <= 400){
        aumentoCRE = SaldoMedio * (20/100)
        SaldoFinal = SaldoMedio + aumentoCRE

         h4ResultadoCREDITO.textContent = "R$"+SaldoFinal.toFixed(2)
    }
        if( SaldoMedio >= 401 && SaldoMedio <= 600){
        aumentoCRE = SaldoMedio * (30/100)
        SaldoFinal = SaldoMedio + aumentoCRE

         h4ResultadoCREDITO.textContent = "R$"+SaldoFinal.toFixed(2)
    }
        if( SaldoMedio >= 601 ){
        aumentoCRE = SaldoMedio * (40/100)
        SaldoFinal = SaldoMedio + aumentoCRE

         h4ResultadoCREDITO.textContent = "R$"+SaldoFinal.toFixed(2)
    }


}

btCalcularCREDITO.onclick = function(){
    CalcularCreditoBancario();
}

// Cardapio Lanchonete

let inputQUANTIDADECARD = document.querySelector("#inputQUANTIDADECARD");
let h4ResultadoCARDAPIO = document.querySelector("#h4ResultadoCARDAPIO");
let btCalcularCARDAPIO = document.querySelector("#btCalcularCARDAPIO");

let selectCARDAPIO = document.querySelector("#selectCARDAPIO");

function CardapioLanchonete(){
    let Quantidade = Number(inputQUANTIDADECARD.value)
    let codigo = (selectCARDAPIO.value)
    let valor 
    let valorPagar

    switch (codigo) {
        case "1CARD": 
            valor = 11; 
            break;
        case "2CARD": 
            valor = 8.5; 
            break;
        case "3CARD": 
            valor = 8; 
            break;
        case "4CARD": 
            valor = 9; 
            break;
        case "5CARD": 
            valor = 10; 
            break;
        case "6CARD": 
            valor = 4.5; 
            break;
        default:

    }

    valorPagar = valor * Quantidade

    h4ResultadoCARDAPIO.textContent = "Total a Pagar de: R$"+valorPagar.toFixed(2)

}

btCalcularCARDAPIO.onclick = function(){
    CardapioLanchonete();
}

// Sistema de Vendas

let inputVENDASvalor  = document.querySelector("#inputVENDASvalor");
let btCalcularVENDAS = document.querySelector("#btCalcularVENDAS");
let h4ResultadoVENDAS = document.querySelector("#h4ResultadoVENDAS");

let selectVendas = document.querySelector("#selectVendas");

function SistemaDeVendas(){
    let ValorVendas = Number(inputVENDASvalor.value)
    let vendas = (selectVendas.value)
    let totalPagar

    switch (vendas){
        case "A_dinheiro":
            totalPagar = ValorVendas * 0.90;
            break;
        case "B_cartao":
            totalPagar = ValorVendas * 0.85;
            break;
        case "C_2vezesSEMjuros":
            totalPagar = ValorVendas;
            break;
        case "D_2vezesCOMjuros":
            totalPagar = ValorVendas * 1.10;
            break;

    }

h4ResultadoVENDAS.textContent = "o Valor total a ser Pago e de R$"+totalPagar.toFixed(2)




}
btCalcularVENDAS.onclick = function(){
    SistemaDeVendas();
}

// Pagamento Professores

let inputHoraAula = document.querySelector("#inputHoraAula");
let btCalcularPROFESSORES = document.querySelector("#btCalcularPROFESSORES");
let h4ResultadoPROFESSORES = document.querySelector("#h4ResultadoPROFESSORES");

let selectPROFESSORES = document.querySelector("#selectPROFESSORES");

function PagamentoProfessores(){
    let qtdAula = Number(inputHoraAula.value);
    let nivel = (selectPROFESSORES.value);
    let salario 
    

    switch(nivel){
        case "Nivel1PRO":
            salario = 12 * qtdAula * 4.5;
            break;
        case "Nivel2PRO":
            salario = 17 * qtdAula * 4.5;
            break;
        case "Nivel3PRO":
            salario = 25 * qtdAula * 4.5;
            break;
       
    }

h4ResultadoPROFESSORES.textContent = "Salario R$"+salario.toFixed(2)

}
btCalcularPROFESSORES.onclick = function(){
    PagamentoProfessores();
}