let inputNum1 = document.querySelector("#inputNum1");
let btCalcular = document.querySelector("#btCalcular");
let h3Resultado = document.querySelector("#h3Resultado");

function CalcularRaio(){
    let R = Number(inputNum1.value);
    let A 

    
    A = 3.14 * (R * R)

    h3Resultado.textContent = "A area da Pizza e de: "+A+"cm"

}

btCalcular.onclick = function(){
    CalcularRaio();
}