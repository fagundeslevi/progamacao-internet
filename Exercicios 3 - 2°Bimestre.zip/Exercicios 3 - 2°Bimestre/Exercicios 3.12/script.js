let inputNum = document.querySelector("#inputNum");
let btVerificar = document.querySelector("#btVerificar");
let h3Resultado = document.querySelector("#h3Resultado");

function Verificar(){
    let Num1 = Number(inputNum.value)
    let centena;
    let dezena;
    let unidade;

    if(Num1 > 999){
        h3Resultado.textContent = "Numero Maior que 3 Digitos, digite outro"
    }else{
        centena = Math.floor (Num1/100) 
        dezena = Math.floor ((Num1 % 100) / 10)
        unidade = Num1 % 10

        h3Resultado.innerHTML = "CENTENA = "+centena+"<br>DEZENA = "+dezena+"<br>UNIDADE = "+unidade
    }

}

btVerificar.onclick = function(){
    Verificar();
}