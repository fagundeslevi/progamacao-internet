let inputBroas = document.querySelector("#inputBroas");
let inputPaes = document.querySelector("#inputPaes");
let btCalcular = document.querySelector("#btCalcular");
let h3Resultado = document.querySelector("#h3Resultado");

function Calcular(){
    let broas = Number(inputBroas.value);
    let paes = Number(inputPaes.value);
    let total;
    let poupar;
    

    total = (broas*0.12)+(paes*1.5);
    poupar = (total*(10/100));
    


    h3Resultado.innerHTML ="total vendido na semana foi de R$"+total+
    "<br> A quantidade a ser depositada na poupanca devera ser de R$"+poupar;




}

btCalcular.onclick = function(){
    Calcular();
}