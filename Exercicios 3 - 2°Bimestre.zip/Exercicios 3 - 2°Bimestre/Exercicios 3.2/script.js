let inputCavalos = document.querySelector("#inputCavalos");
let btVerificar = document.querySelector("#btVerificar");
let h3Resultado = document.querySelector("#h3Resultado");

function Calcular(){
    let cavalos = Number(inputCavalos.value);
    let total

    total = cavalos * 4

    h3Resultado.textContent = "Serao Necessarios "+total+" Ferraduras, Para os "+
    cavalos+" cavalos.";



}

btVerificar.onclick = function(){
    Calcular();
}