let inputDia = document.querySelector("#inputDia");
let inputMes = document.querySelector("#inputMes");
let btCalcular = document.querySelector("#btCalcular");
let h3Resultado = document.querySelector("#h3Resultado");

function Dias(){
    let dias = Number(inputDia.value);
    let mes = Number(inputMes.value);
    let total;
    
    total = dias+(mes*30);

    h3Resultado.textContent ="se passaram "+total+" dias desde o inicio do ano";

}

btCalcular.onclick = function(){
    Dias();
}