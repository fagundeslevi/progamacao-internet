let inputDias = document.querySelector("#inputDias");
let btVerificar = document.querySelector("#btVerificar");
let h3Resultado = document.querySelector("#h3Resultado");

function VerificarDias(){
    let dias = Number(inputDias.value);
    let mes;
    let anos;

    mes = dias/30
    anos = dias/365

    h3Resultado.textContent = "Estamos a "+anos.toFixed(0)+" ano(s), "
    +mes.toFixed(0)+" meses, "+dias+" dias Sem acidentes";
    
    //toFixed(0) - Limitar o numero de casas apos o ponto


}

btVerificar.onclick = function(){
    VerificarDias();
}