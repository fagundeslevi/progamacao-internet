let inputNome = document.querySelector("#inputNome");
let inputIdade = document.querySelector("#inputIdade");
let btCalcular = document.querySelector("#btCalcular");
let h3Resultado= document.querySelector("#h3Resultado");

function VerificarIdade(){
    let idade = Number(inputIdade.value);
    let dias;
    let nome = inputNome.value;

    dias = idade * 365

    h3Resultado.innerHTML = nome+", voce ja viveu "+dias+" dias";

}

btCalcular.onclick = function(){
    VerificarIdade();
}