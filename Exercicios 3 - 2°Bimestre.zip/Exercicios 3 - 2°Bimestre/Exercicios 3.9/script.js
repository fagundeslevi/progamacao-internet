let inputX1 = document.querySelector("#inputX1");
let inputY1 = document.querySelector("#inputY1");
let inputX2 = document.querySelector("#inputX2");
let inputY2 = document.querySelector("#inputY2");
let btCalcular = document.querySelector("#btCalcular");
let h3Resultado = document.querySelector("#h3Resultado");

function CalcularDistancia(){
    let x1 = Number(inputX1.value);
    let y1 = Number(inputY1.value);
    let x2 = Number(inputX2.value);
    let y2 = Number(inputY2.value);
    let Xtotal;
    let Ytotal;
    let totalGeral;

    Xtotal = x2 - x1
    Ytotal = y2 - y1
    totalGeral = (Xtotal*Xtotal)+(Ytotal*Ytotal)
    
    h3Resultado.textContent = Math.sqrt(totalGeral)

}

btCalcular.onclick = function(){
    CalcularDistancia();
}