let inputPequena = document.querySelector("#inputPequena");
let inputMedia = document.querySelector("#inputMedia");
let inputGrande = document.querySelector("#inputGrande");
let btCalcular = document.querySelector("#btCalcular");
let h3Resultado = document.querySelector("#h3Resultado");

function ValorArrecadado(){
    let Pequena = Number(inputPequena.value);
    let Media = Number(inputMedia.value);
    let Grande = Number(inputGrande.value);
    let Arrecadado;

    Arrecadado = (Pequena*10) + (Media*12) + (Grande*15);

    h3Resultado.textContent = "Total Arrecado foi de R$"+Arrecadado;

}

btCalcular.onclick = function(){
    ValorArrecadado();
}