let inputNum1 = document.querySelector("#inputNum1");
let btCalcular = document.querySelector("#btCalcular");
let h3Resultado = document.querySelector("#h3Resultado");

function DividirConta(){
    let ContaBase = Number(inputNum1.value);
    let Carlos;
    let Andre;
    let Felipe;
    let TotalDividido;

    TotalDividido = Math.floor(ContaBase/3)

    Carlos = TotalDividido
    Andre = TotalDividido

    Felipe = ContaBase - Carlos - Andre

    h3Resultado.innerHTML = "Carlos Vai Pagar R$"
    +Carlos.toFixed(2)+"<br> Andre Vai Pagar R$"
    +Andre.toFixed(2)+"<br>Felipe Vai Pagar R$"
    +Felipe.toFixed(2)


}

btCalcular.onclick = function(){
    DividirConta();
}