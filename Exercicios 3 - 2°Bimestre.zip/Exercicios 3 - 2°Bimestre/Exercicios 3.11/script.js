let inputSalario = document.querySelector("#inputSalario");
let btCalcular = document.querySelector("#btCalcular");
let h3Resultado = document.querySelector("#h3Resultado");

function CalcularSalario(){
    let SalarioIncial = Number(inputSalario.value);
    let Salario15;
    let SalarioImposto;
    let Salario8;

    Salario15 = SalarioIncial * (15/100)
    Salario15 = Salario15 + SalarioIncial

    SalarioImposto = Salario15 * (8/100)
    Salario8 = Salario15 - SalarioImposto


    h3Resultado.innerHTML = "Salario Inicial = "+SalarioIncial+"<br> Salario (Aumento de 15%) = "
    +Salario15+"<br> Salario Final = "+Salario8



}

btCalcular.onclick = function(){
    CalcularSalario();
}