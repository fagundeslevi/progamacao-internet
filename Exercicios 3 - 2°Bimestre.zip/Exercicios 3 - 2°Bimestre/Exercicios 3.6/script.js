let inputPeso = document.querySelector("#inputPeso");
let btCalcular = document.querySelector("#btCalcular");
let h3Resultado = document.querySelector("#h3Resultado");

function CalcularPeso(){
    let peso = Number(inputPeso.value);
    let valorApagar;

    valorApagar = peso*12

    h3Resultado.textContent = "Devera ser pago R$"+valorApagar;



}

btCalcular.onclick = function(){
    CalcularPeso();
}