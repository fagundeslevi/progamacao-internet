let inputDim1 = document.querySelector("#inputDim1");
let inputDim2 = document.querySelector("#inputDim2");
let btArea = document.querySelector("#btArea");
let h3Resultado = document.querySelector("#h3Resultado");

function CalcularArea(){
    let base = Number(inputDim1.value);
    let altura = Number(inputDim2.value);
    let Area;

    Area = base*altura

    h3Resultado.textContent = Area+"m²";

}

btArea.onclick = function(){
    CalcularArea();
}