let inputPago = document.querySelector("#inputPago");
let inputGasolina = document.querySelector("#inputGasolina");
let btCalcular = document.querySelector("#btCalcular");
let h3Resultado = document.querySelector("#h3Resultado");

function PrecoGasolina(){
    let ValorPago = Number(inputPago.value)
    let ValorGasolina = Number(inputGasolina.value)
    let litros

    litros = ValorPago/ValorGasolina

    h3Resultado.textContent = "Foi colocado "+litros.toFixed(2)+" litros"

}

btCalcular.onclick = function(){
    PrecoGasolina();
}