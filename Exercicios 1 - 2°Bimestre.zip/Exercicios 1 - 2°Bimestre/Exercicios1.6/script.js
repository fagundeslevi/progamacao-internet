let inputNum1 = document.querySelector("#inputNum1");
let inputNum2 = document.querySelector("#inputNum2");
let inputNum3 = document.querySelector("#inputNum3");
let inputNum4 = document.querySelector("#inputNum4");
let btTestar = document.querySelector("#btTestar");
let h3Resultado = document.querySelector("#h3Resultado");

function TestarMenor(){
    let num1 = Number(inputNum1.value);
    let num2 = Number(inputNum2.value);
    let num3 = Number(inputNum3.value);
    let num4 = Number(inputNum4.value);

if( (num1 < num2) && (num1 < num3) && (num1 < num4) ){
    h3Resultado.textContent = num1
}
if( (num2 < num1) && (num2 < num3) && (num2 < num4) ){
    h3Resultado.textContent = num2
}
if( (num3 < num2) && (num3 < num1) && (num3 < num4) ){
    h3Resultado.textContent = num3
}
if( (num4 < num2) && (num4 < num3) && (num4 < num1) ){
    h3Resultado.textContent = num4
}

}
btTestar.onclick = function(){
    TestarMenor();
}