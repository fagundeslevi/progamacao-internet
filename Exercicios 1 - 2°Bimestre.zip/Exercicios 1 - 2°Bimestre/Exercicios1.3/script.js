let btCalcular = document.querySelector("#btCalcular");
let inputNum1 = document.querySelector("#inputNum1");
let resultado = document.querySelector("#resultado");
let num2;

function somarNumeros(){

    let num1 = Number(inputNum1.value);
    
    num2 = (num1*(1/100));
    resultado.textContent = (num1 + num2);
}

btCalcular.onclick = function(){
    somarNumeros();
}