let inputNum1 = document.querySelector("#inputNum1");
let inputNum2 = document.querySelector("#inputNum2");
let inputNum3 = document.querySelector("#inputNum3");
let somaMedia = document.querySelector("#somaMedia");
let ponderada = document.querySelector("#ponderada");
let aritmetica = document.querySelector("#aritmetica");
let btCalcular = document.querySelector("#btCalcular");
let mediaMedia = document.querySelector("#mediaMedia");

function Numeros(){
    let num1 = Number(inputNum1.value);
    let num2 = Number(inputNum2.value);
    let num3 = Number(inputNum3.value);
    let num4;
    let num5;
    let num6;
    let num7;
    let num8;

    //ponderada
    num4 = ((num1*3)+(num2*2)+(num3*5));
    num5 = (num4/(3+2+5));
    //aritmetica
    num6 = ((num1 + num2 + num3)/3);
    //soma media
    num7 = (num6 + num5);
    //Media Media
    num8 = (num7/2);

    mediaMedia.textContent = num8
    somaMedia.textContent = num7
    ponderada.textContent = num5
    aritmetica.textContent = num6


}

btCalcular.onclick = function(){
    Numeros();
}
