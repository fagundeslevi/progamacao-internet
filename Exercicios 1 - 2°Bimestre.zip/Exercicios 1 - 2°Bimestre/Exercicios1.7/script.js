let inputNum1 = document.querySelector("#inputNum1");
let btresultado = document.querySelector("#btresultado");
let resultado = document.querySelector("#resultado");

function verificarImpar(){
    let num1 = Number(inputNum1.value);
    
if (num1 % 2 === 0){
    resultado.textContent = "par";   
}else{
    resultado.textContent = "impar";  
}

}

btresultado.onclick = function(){
    verificarImpar();
}