let inputNum1 = document.querySelector("#inputNum1");
let inputNum2 = document.querySelector("#inputNum2");
let btTestar = document.querySelector("#btTestar");
let h3Resultado = document.querySelector("#h3Resultado");

function TestarMaior(){
    let num1 = Number(inputNum1.value);
    let num2 = Number(inputNum2.value);

    if( num1 > num2){
        h3Resultado.textContent = "Maior entre os dois: "+num1;
    }else{
        h3Resultado.textContent = "Maior entre os dois: "+num2;
    }


}

btTestar.onclick = function(){
    TestarMaior();
}
