let inputNum1 = document.querySelector("#InputNum1");
let inputNum2 = document.querySelector("#InputNum2");
let btCalcular = document.querySelector("#btCalcular");

function Calcular(){
    let num1 = Number(inputNum1.value);
    let num2 = Number(inputNum2.value);

    resultadosoma.textContent = (num1 + num2);
    resultadosub.textContent = (num1 - num2);
    resultadomult.textContent = (num1 * num2);
    resultadodiv.textContent = (num1 / num2);

}

btCalcular.onclick = function(){
    Calcular();
}