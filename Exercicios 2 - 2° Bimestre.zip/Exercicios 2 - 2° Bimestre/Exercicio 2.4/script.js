let inputsabor1 = document.querySelector("#inputsabor1");
let inputsabor2 = document.querySelector("#inputsabor2");
let inputsabor3 = document.querySelector("#inputsabor3");
let inputsabor4 = document.querySelector("#inputsabor4");
let inputRefri = document.querySelector("#inputRefri");
let btResultado = document.querySelector("#btResultado");
let Resultado = document.querySelector("#Resultado");

function Calcular(){

    let refri = Number(inputRefri.value);
    let sabor1 = (inputsabor1.value);
    let sabor2 = (inputsabor2.value);
    let sabor3 = (inputsabor3.value);
    let sabor4 = (inputsabor4.value);
    let sabores = 0;
    let resultado1;
    let resultado2;


    if( sabor1 != "" ){ //input1
         //soma sabores 
        sabores = sabores +1
    }
    if( sabor2 != "" ){ //input2
         //soma sabores  
        sabores += 1 //mesma coisa que (sabores = sabores + 1)
    }
    if( sabor3 != "" ){ //input3
        //soma sabores  
       sabores += 1
    }
    if( sabor4 != "" ){ //input4
        //soma sabores  
       sabores += 1
   }

    resultado2 = refri * 7
    resultado1 = sabores * 12 


    let resultado3 = resultado1 + resultado2;

    Resultado.innerHTML = "ficou um total de: R$"+resultado3+"<br>"+
    "O Primeiro sabor informado foi: "+sabor1+"<br>"+
    "O segundo sabor informado foi: "+sabor2+"<br>"+
    "O Terceiro sabor informado foi: "+sabor3+"<br>"+
    "O Quarto sabor informado foi: "+sabor4; 


    
}

btResultado.onclick = function(){
    Calcular();
}

