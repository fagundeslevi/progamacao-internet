let inputNum1 = document.querySelector("#inputNum1");
let resultado1 = document.querySelector("#resultado1");
let resultado2 = document.querySelector("#resultado2");
let resultado5 = document.querySelector("#resultado5");
let resultado10 = document.querySelector("#resultado10");
let btCalcular = document.querySelector("#btCalcular");




function calculardolar(){
    
    let inicial = Number(inputNum1.value);
    let Num1
    let Num2
    let Num3
    let Num4
    let Num5
    let Num6
    let Num7
    let Num8

    //1%
    Num1 = (inicial*(1/100));
    Num2 = (inicial + Num1);

    //2%
    Num3 = (inicial*(2/100));
    Num4 = (inicial + Num3);
    
    //5%
    Num5 = (inicial*(5/100));
    Num6 = (inicial + Num5);
    
    //10%
    Num7 = (inicial*(10/100));
    Num8 = (inicial + Num7);
    
    resultado1.textContent = Num2
    resultado2.textContent = Num4
    resultado5.textContent = Num6
    resultado10.textContent = Num8

}

btCalcular.onclick = function(){
    calculardolar();
}
