let inputNum1 = document.querySelector("#InputNum1");
let btCalcular = document.querySelector("#btCalcular");
let resultadoQUEIJO = document.querySelector("#resultadoQUEIJO");
let resultadoOVO = document.querySelector("#resultadoOVO");

function CalcularOmelete(){
    let inicial = Number(inputNum1.value);


    resultadoQUEIJO.textContent = (inicial*50);
    resultadoOVO.textContent = (inicial*2);

}

btCalcular.onclick = function(){
    CalcularOmelete();
}